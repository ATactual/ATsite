// Global type definitions for the server

declare global {
  var threatIntelligenceCache: {
    [key: string]: any;
  };
}

export {};