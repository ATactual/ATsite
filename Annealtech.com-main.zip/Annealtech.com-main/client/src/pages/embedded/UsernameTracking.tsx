import UsernameTrackingEmbed from "@/components/embedded/UsernameTrackingEmbed";

export default function UsernameTracking() {
  return (
    <div id="embedded-tool-page">
      <UsernameTrackingEmbed />
    </div>
  );
}